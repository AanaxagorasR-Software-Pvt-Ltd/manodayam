export const API_HOST_URL = "http://swarnratnaindia.com/dev-apiman";
export const API_MIDD = "/api";
export const LOGIN_API = "/auth/user/login";
export const REGISTER_API = "/auth/user/new";
export const APPOINTMENT_LIST = "/appointment-list";

export const API_ADMIN_URL = API_HOST_URL + API_MIDD 
