const globalDataGroupCall = {
  groupCallLink:
    window.location.hostname === "localhost"
      ? "http://localhost:1000/manodayam"
      : "https://swarnratnaindia.com/dev-live-oneTomany/dev-live-oneTomany",
};
export default globalDataGroupCall;
