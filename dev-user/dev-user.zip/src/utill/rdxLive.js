const globalDataLive = {
    liveLink:
      window.location.hostname === "localhost"
        ? "http://localhost:4000/manodayam"
        : "https://swarnratnaindia.com/dev-live/dev-live",
  };
  export default globalDataLive;
  