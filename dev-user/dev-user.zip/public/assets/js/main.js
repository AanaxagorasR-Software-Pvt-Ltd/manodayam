$(document).ready(function(){
    $(".fgt-btn").click(function(){
      $(".forgot-password").show();
    });
    $(".fgt-btn").click(function(){
        $(".login-hide").hide();
      });
      $(".old-password").click(function(){
        $(".login-hide").show();
      });
      $(".old-password").click(function(){
        $(".forgot-password").hide();
      });
      $(".crt-btn").click(function(){
        $(".login-hide").hide();
      });
      $(".crt-btn").click(function(){
        $(".signup-hide").show();
      });
      $(".lgn-btn").click(function(){
        $(".signup-hide").hide();
      });
      $(".lgn-btn").click(function(){
        $(".login-hide").show();
      });
      $(".sgn-btn").click(function(){
        $(".forgot-password").hide();
      });
      
  
  });


  $(document).ready(function(){
    $(".ctn-btn").click(function(){
      $(".banner-ot-content").hide();
    });
    $(".ctn-btn").click(function(){
        $(".questions-detail").show();
      });
    
  });
  $(document).ready(function(){
    $(".spr-btn").click(function(){
      $(".related-videos").show();
    });
  });


