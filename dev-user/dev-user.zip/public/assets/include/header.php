<fixed class="fixed">
<div class="header-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-4">
                    <div class="top-logo">
                        <a href="index.php"><img src="image/logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-8">
                    <div class="header-contact">
                    <button class="btn-web hvr-float-shadow" data-toggle="tooltip" title="Profile!"><a href="profile.php"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a></button>
                    <button class="btn-web hvr-float-shadow" data-toggle="tooltip" title="Cart!"><a href="cart.php"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></a></button>
                        <i class="fa fa-mobile" aria-hidden="true"></i>
                        <a href="telto:+92 1234567 890">+92 1234567 890</a>
                        <p>contact us for help</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <header class="web-header">
        <div class="container">
            <nav class="navbar navbar-expand-md">

                <a class="navbar-brand d-logo" href="#"><img src="image/logo.png" alt=""></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                  <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span>
                </button>
                
                <div class="collapse navbar-collapse" id="collapsibleNavbar">
                    <ul class="navbar-nav nav-custom">
                        <li class="nav-item">
                            <a href="index.php" class="nav-link">Home</a>
                        </li>
                        <li class="nav-item">
                            <a href="#about" class="nav-link">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a href="support.php" class="nav-link">Support Network</a>
                        </li>
                        <li class="nav-item">
                            <a href="library.php" class="nav-link">Digital Human Library</a>
                        </li>
                        <li class="nav-item">
                            <a href="research.php" class="nav-link">Research</a>
                        </li>
                        <li class="nav-item">
                            <a href="contact.php" class="nav-link">Contact</a>
                        </li>
                        <li class="nav-item">
                            <!-- <button class="btn btn-web hvr-bounce-to-right">Try Manodayam</button>-->
                        </li>
                    </ul>
                    <ul class="navbar-nav nav-custom ml-auto btn-nav">
                        <li class="nav-item">
                            <button class="btn-web hvr-float-shadow ipad-none"  data-toggle="modal" data-target="#myModal">Login</button>
                        </li>
                        <li class="nav-item">
                            <button class="btn-web hvr-float-shadow ipad-btn"  data-toggle="modal" data-target="#myModal">Login</button>
                        </li>
                        <li class="nav-item">
                            <button class="btn-web hvr-float-shadow ipad-none"  data-toggle="modal" data-target="#myModal">Register</button>
                        </li>
                        <li class="nav-item">
                            <button class="btn-web hvr-float-shadow" data-toggle="modal" data-target="#doctor-modal">Doctor</button>
                        </li>
                    </ul>

                </div>
            </nav>

            
        </div>
    </header>
</fixed>

    <a href="#" class="scrollToTop"><i class="fa fa-hand-pointer-o" aria-hidden="true"></i></a>


  