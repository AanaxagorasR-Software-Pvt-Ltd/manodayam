module.exports = {
    DOMAIN_NAME: "localhost:3001",
    MEDIA_PATH: "/uploads"    
} 