// const SUPPORT_EMAIL = -"supprot.virtuladoc@gmail.com"
// const EMAIL_PASSWORD = "Su100$Br"
// const DOMAIN_NAME =  "http://localhost"
// const PORT = "8080"
// const MEDIA_PATH = "uploads"
// const MEDIA_TYEP_1 = "images"
// const MEDIA_TYEP_2 = "videos"
// const SECRET = "HDK098LO909JHJ"



// ========================prod==========
 const SUPPORT_EMAIL = "supprot.virtuladoc@gmail.com"
 const EMAIL_PASSWORD = "Su100$Br"
 const DOMAIN_NAME =  "https://swarnratnaindia.com/dev-apiman"
//  const DOMAIN_NAME =  " http://localhost:3020"
 const PORT = ""
 const MEDIA_PATH = "uploads"
 const MEDIA_TYEP_1 = "images"
 const MEDIA_TYEP_2 = "videos"
 const SECRET = "HDK098LO909JHJ"


 module.exports = {
    SUPPORT_EMAIL,
    EMAIL_PASSWORD,
    DOMAIN_NAME,
    PORT,
    MEDIA_PATH,
    MEDIA_TYEP_1,
    MEDIA_TYEP_2,
    SECRET
 }
